# ThemedProject
![latest release badge](https://img.shields.io/github/v/release/Osanosa/ThemedProject?sort=semver)
![total-download-count](https://img.shields.io/github/downloads/Osanosa/ThemedProject/total?color=brightgreen)

A8+, Magisk needed

Latest screenshots are available at https://www.themed.pro/screenshots
