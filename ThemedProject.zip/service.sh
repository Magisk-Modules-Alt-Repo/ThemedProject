pm list packages | grep pro.themed.manager || pm install /data/adb/modules/ThemedProject/system/product/app/ThemedManager/*.apk
